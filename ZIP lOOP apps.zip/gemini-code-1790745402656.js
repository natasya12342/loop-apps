// Nama File: Code.gs

const SHEET_ID = 'MASUKKAN_ID_SPREADSHEET_ANDA_DI_SINI'; 

function doGet(e) {
  // createTemplateFromFile + evaluate() wajib digunakan agar tag <?!= ?> diproses jadi UI 3D
  const template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
    .setTitle('Loop - 3D Circle')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Fungsi untuk menyisipkan Script.html ke dalam Index.html tanpa error teks
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// Fungsi penyimpanan data ke Google Sheets
function saveMessage(username, message) {
  try {
    const sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    const timestamp = new Date();
    sheet.appendRow([timestamp, username, message]);
    return { success: true, message: "Pesan tersimpan" };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}